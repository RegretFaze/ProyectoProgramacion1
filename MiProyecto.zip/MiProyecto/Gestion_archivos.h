#ifndef GESTION_ARCHIVOS_H
#define GESTION_ARCHIVOS_H

#include "Validaciones_funciones_comunes.h" // Necesario para Vehiculo, MAX_VEHICULOS, ARCHIVO_DATOS

// Declaraciones de funciones para cargar y guardar datos
void cargarDatos();
void guardarDatos();

#endif // GESTION_ARCHIVOS_H
